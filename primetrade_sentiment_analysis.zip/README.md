# Trader Performance vs Market Sentiment
Primetrade.ai – Data Science Intern Assignment

## How to run
Upload the folder to Colab or run locally with Jupyter.
